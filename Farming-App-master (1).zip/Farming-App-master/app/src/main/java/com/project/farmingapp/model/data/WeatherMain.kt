package com.project.farmingapp.model.data

data class WeatherMain(val temp:Float,val humidity:String,val temp_min:String,val temp_max:String)