package com.project.farmingapp.model.data

import java.sql.Timestamp

data class CartItem(var quantity: Int, val time: String)