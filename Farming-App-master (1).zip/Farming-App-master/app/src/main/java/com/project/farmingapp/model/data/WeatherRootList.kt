package com.project.farmingapp.model.data

//data class WeatherRootList(val list:List<WeatherList>) : List<WeatherList>
data class WeatherRootList(val list: List<WeatherList>)