package com.project.farmingapp.model.data

data class APMCMain(val updated_date: String, val records: List<APMCRecords>)