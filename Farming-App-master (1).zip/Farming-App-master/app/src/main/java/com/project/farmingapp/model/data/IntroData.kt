package com.project.farmingapp.model.data

data class IntroData (
    val title :String,
    val description: String,
    val image: Int
)