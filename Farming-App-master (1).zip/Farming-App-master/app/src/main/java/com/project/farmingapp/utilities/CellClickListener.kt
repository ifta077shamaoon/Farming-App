package com.project.farmingapp.utilities

interface CellClickListener {
    fun onCellClickListener(name: String)

}